import StatCard from "./components/StatCard";

// TEST images
import test1 from "./assets/vk1.jpg";
import test2 from "./assets/vk2.jpg";

// ODI images
import odi1 from "./assets/vk3.jpg";
import odi2 from "./assets/vk1.jpg";

// T20 images
import t201 from "./assets/vk2.jpg";
import t202 from "./assets/vk3.jpg";

function App() {
  return (
    <div style={{ padding: "40px", background: "#0f0f0f" }}>
      <h1 style={{ color: "white" }}>Virat Kohli Career</h1>

      <StatCard
        title="Test Cricket"
        images={[test1, test2]}
        stats={{
          Matches: 123,
          Runs: 9230,
          Average: 46.85,
          Centuries: 30,
          Fifties: 31,
        }}
      />

      <StatCard
        title="ODI Cricket"
        images={[odi1, odi2]}
        stats={{
          Matches: 308,
          Runs: 14557,
          Average: 58.46,
          Centuries: 53,
          Fifties: 76,
        }}
      />

      <StatCard
        title="T20I Cricket"
        images={[t201, t202]}
        stats={{
          Matches: 125,
          Runs: 4188,
          Average: 48.69,
          Centuries: 1,
          Fifties: 38,
        }}
      />
    </div>
  );
}

export default App;
