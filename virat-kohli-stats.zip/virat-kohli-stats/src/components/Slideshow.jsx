import { useState } from "react";

function Slideshow({ images }) {
  const [index, setIndex] = useState(0);

  const nextSlide = () => {
    setIndex((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setIndex((prev) =>
      prev === 0 ? images.length - 1 : prev - 1
    );
  };

  return (
    <div style={{ position: "relative", width: "300px", margin: "auto" }}>
      <img
        src={images[index]}
        alt="slide"
        style={{ width: "100%", borderRadius: "10px" }}
      />

      {/* Left arrow */}
      <button
        onClick={prevSlide}
        style={{
          position: "absolute",
          top: "50%",
          left: "0",
          transform: "translateY(-50%)",
          background: "rgba(0,0,0,0.6)",
          color: "white",
          border: "none",
          fontSize: "20px",
          cursor: "pointer",
        }}
      >
        ◀
      </button>

      {/* Right arrow */}
      <button
        onClick={nextSlide}
        style={{
          position: "absolute",
          top: "50%",
          right: "0",
          transform: "translateY(-50%)",
          background: "rgba(0,0,0,0.6)",
          color: "white",
          border: "none",
          fontSize: "20px",
          cursor: "pointer",
        }}
      >
        ▶
      </button>
    </div>
  );
}

export default Slideshow;
