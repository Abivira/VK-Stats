import Slideshow from "./Slideshow";

function StatCard({ title, images, stats }) {
  return (
    <div
      style={{
        display: "flex",
        gap: "20px",
        padding: "20px",
        marginBottom: "30px",
        border: "1px solid #6f0909ff",
        borderRadius: "12px",
        background: "#5d5858ff",
        color: "white",
      }}
    >
      {/* Left: Slideshow */}
      <Slideshow images={images} />

      {/* Right: Stats */}
      <div>
        <h2>{title}</h2>
        <ul>
          {Object.entries(stats).map(([key, value]) => (
            <li key={key}>
              <b>{key}</b>: {value}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default StatCard;
